﻿namespace StudentWebApplication.Models
{
    public class Student
    {
        public int student_Id { get; set; }
        public string student_Name { get; set; }
        public string Email { get; set; }
        public string mobile_no { get; set; }
        public string student_address { get; set; }
        public decimal fees { get; set; }
        public string status { get; set; }
    }
}
