﻿using Microsoft.AspNetCore.Mvc;

using StudentWebApplication.Servies;
using StudentWebApplication.Models;
namespace StudentWebApplication.Controllers
{
    public class StudentController : Controller
    {
        private readonly IStudentService studentService;

        public StudentController(IStudentService studentService)
        {
            this.studentService = studentService;
        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Insert()
        {

            return View();
        }

        [HttpPost]
        public IActionResult Insert(Student student)
        {
            studentService.insert(student);
            return RedirectToAction("GetStudents");
        }

        public IActionResult Delete()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Delete(int student_Id)
        {
            studentService.delete(student_Id);
            return RedirectToAction("GetStudents");
        }
        [HttpGet]
        public IActionResult GetStudents()
        {
            //return Json(studentService.GetStudents());
            var students = studentService.GetStudents();
            return View(students);
        }
        public IActionResult Update()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Update(Student student)
        {
            studentService.update(student);
            return RedirectToAction("GetStudents");
        }
        public IActionResult GetStudentssort()
        {
            return View(studentService.GetStudentssort());
        }
    }
}

