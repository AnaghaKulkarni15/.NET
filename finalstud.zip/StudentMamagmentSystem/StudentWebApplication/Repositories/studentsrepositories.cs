﻿using Microsoft.EntityFrameworkCore;
using StudentWebApplication.Models;
namespace StudentWebApplication.Repositories
{
    public class studentsrepositories:DbContext
    {
       public DbSet<Student> students {  get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            string constring = @"server=localhost;port=3306;user=root;password=2001;database=studentnet";
            optionsBuilder.UseMySQL(constring);
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Student>(entity =>
            {
                entity.HasKey(p=>p.student_Id);
                entity.Property(p => p.student_Name);
            });
        }
    }
}
