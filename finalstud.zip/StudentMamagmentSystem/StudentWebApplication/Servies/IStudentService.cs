﻿using StudentWebApplication.Models;

namespace StudentWebApplication.Servies
{
    public interface IStudentService
    {
        List<Student> GetStudents();
        Student insert(Student student);
        Student update(Student student);
        void delete(int id);
        List<Student> GetStudentssort();

    }
}
