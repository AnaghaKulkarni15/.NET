﻿using StudentWebApplication.Models;
using StudentWebApplication.Repositories;

namespace StudentWebApplication.Servies
{
    public class StudentService : IStudentService
    {
       
        public void delete(int id)
        {
            using (var context = new studentsrepositories())
            {
                var student = context.students.Find(id);
                if (student != null)
                {
                    context.students.Remove(student);
                    context.SaveChanges();
                }                 
            }
        }

        public List<Student> GetStudents()
        {
            using (var context = new studentsrepositories())
            {
                var students = from Student
                              in context.students
                              select Student;
                return students.ToList<Student>();
            }
        }

        public List<Student> GetStudentssort()
        {
           using (var context =new studentsrepositories())
            {
                var student = context.students.OrderBy(s=>s.status=="active"?0:1).ToList();
                return student.ToList<Student>();
            }
        }

        public Student insert(Student student)
        {   
            using (var context = new studentsrepositories())
            {
                context.students.Add(student);
                context.SaveChanges();
            }
            return student;
        
        }

        public Student update(Student student)
        {
           using (var context =new studentsrepositories())
            {
                if (student != null)
                {
                    context.students.Update(student);
                    context.SaveChanges();
                }
            }
            return student;
        }
    }
}
