﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Student_Management.Services;
using Student_Management.Entities;

namespace Student_Management.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private IStudentService _studentService;

        public StudentController(IStudentService studentService)
        {
            _studentService = studentService;
        }

        [HttpGet]
        public IActionResult GetAllStudents()
        {
            return Ok(_studentService.GetAllStudents());
        }

        [HttpGet("getbyId/{id}")]
        public IActionResult GetStudentById(int id)
        {
            return Ok(_studentService.GetStudentById(id));
        }

        [HttpPost("insert")]
        public IActionResult InsertStud(Student student)
        {
            return Ok(_studentService.InsertStud(student));
        }

        [HttpPut("update/{id}")]

        public IActionResult UpdateStud(int id,Student student)
        {
            return Ok(_studentService.UpdateStud(id, student));
        }

        [HttpDelete("delete/{id}")]
        public IActionResult DeleteStud(int id)
        {
            return Ok(_studentService.DeleteStud(id));
        }



    } 
}
