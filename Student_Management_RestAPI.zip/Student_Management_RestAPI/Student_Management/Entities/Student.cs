﻿namespace Student_Management.Entities
{
    public class Student
    {
        public int StudId { get; set; }

        public string Name { get; set; }

        public string Email { get; set; }

        public string Mobileno { get; set; }

        public string Address { get; set; }

        public DateTime Admission_date { get; set; }

        public Double Fees { get; set; }

        public Boolean Status { get; set; }


    }
}
