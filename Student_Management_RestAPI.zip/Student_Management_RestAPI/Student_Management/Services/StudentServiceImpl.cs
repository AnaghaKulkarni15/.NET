﻿using Student_Management.Entities;
using Student_Management.Repositories;

namespace Student_Management.Services
{
    public class StudentServiceImpl : IStudentService
    {
        public List<Student> GetAllStudents()
        {
            IStudentRepository repo = new StudentRepositoryImpl();
            return repo.GetAllStudents();
        }

        public List<Student> GetStudentById(int id)
        {
            IStudentRepository repo = new StudentRepositoryImpl();    
            return repo.GetStudentById(id);
        }

        public Boolean InsertStud(Student student)
        {
            IStudentRepository repo = new StudentRepositoryImpl();
            return repo.InsertStud(student);
        }

        public Boolean UpdateStud(int id, Student student)
        {
            IStudentRepository repo = new StudentRepositoryImpl();  
            return repo.UpdateStud(id, student);
        }


        public Boolean DeleteStud(int id)
        {
            IStudentRepository repo = new StudentRepositoryImpl();    
            return repo.DeleteStud(id);
        }


    }
}
