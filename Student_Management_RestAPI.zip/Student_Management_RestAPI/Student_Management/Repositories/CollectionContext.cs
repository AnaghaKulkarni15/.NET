﻿using System.Collections.Generic;
using System.Reflection.Emit;
using Microsoft.EntityFrameworkCore;
using Student_Management.Entities;

namespace Student_Management.Repositories
{
        public class CollectionContext : DbContext
        {
            public DbSet<Student> studentsss { get; set; }
            protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
            {
                string conString = @"server=localhost;port=3306;user=root;password=9311811@;database=Stud_info";
                optionsBuilder.UseMySQL(conString);
            }

            protected override void OnModelCreating(ModelBuilder modelBuilder)

            {
                base.OnModelCreating(modelBuilder);
                modelBuilder.Entity<Student>(entity =>
                {
                    entity.HasKey(e => e.StudId);
                    entity.Property(e => e.Name).IsRequired();
                    entity.Property(e => e.Email).IsRequired();
                    entity.Property(e => e.Mobileno).IsRequired();
                    entity.Property(e => e.Address).IsRequired();
                    entity.Property(e => e.Admission_date).IsRequired();
                    entity.Property(e => e.Fees).IsRequired();  
                    entity.Property(e =>e.Status).IsRequired(); 
                });

                modelBuilder.Entity<Student>().ToTable("Student");
            }
        }
    }


