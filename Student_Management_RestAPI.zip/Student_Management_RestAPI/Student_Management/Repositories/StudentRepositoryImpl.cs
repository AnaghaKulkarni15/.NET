﻿using Student_Management.Entities;


namespace Student_Management.Repositories
{
    public class StudentRepositoryImpl : IStudentRepository
    {

        public List<Student> GetAllStudents()
        {
            using(var context = new CollectionContext())
            {
                var students = from stud in context.studentsss 
                               select stud;
    
                return students.ToList<Student>();
            }
        }

        public List<Student> GetStudentById(int id)
        {
            using(var context = new CollectionContext())
            {
                var students = from stud in context.studentsss
                               where stud.StudId == id
                               select stud;
                return students.ToList<Student>();
            }
        }

        public Boolean InsertStud(Student student)
        {
            using(var context = new CollectionContext())
            {
                context.studentsss.Add(student);
                context.SaveChanges();
                return true;
            }
        }

        public bool UpdateStud(int id , Student student)
        {
            using(var context = new CollectionContext())
            {
                context.studentsss.Update(student);
                context.SaveChanges();
            }
            return true;
        }
        public Boolean DeleteStud(int id)
        {
            using( var context = new CollectionContext())
            {
                var delstud = from stud in context.studentsss
                              where stud.StudId == id
                              select stud;
                context.studentsss.RemoveRange(delstud);
                context.SaveChanges();
            }
            return true;
        }




    }
}
