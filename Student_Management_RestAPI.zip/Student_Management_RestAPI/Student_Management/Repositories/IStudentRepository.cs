﻿using Student_Management.Entities;

namespace Student_Management.Repositories

{
    public interface IStudentRepository
    {
        List<Student> GetAllStudents();

        List<Student> GetStudentById(int id);

        bool InsertStud(Student student);

        bool UpdateStud(int id ,Student student);

        bool DeleteStud(int id);

        //bool searchBystatus (bool status);

        //bool SortBystatus(bool status);
    }
}
